var valorEmDolarTexto = prompt("Qual o valor em dolar que você quer converter?"); valorEmDolarNumero = parseFloat(valorEmDolarTexto); valorEmReal = valorEmDolarNumero * 5.51; valorEmRealFixado = valorEmReal.toFixed(2)

alert(valorEmRealFixado)